package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.repository.DebtRepository
import com.example.data.repository.SettingsRepository

class DebtApplication : Application() {
    val firebaseManager = AldionFirebaseManager()
    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { DebtRepository(database, firebaseManager) }
    val settingsRepository by lazy { SettingsRepository(this) }

    override fun onCreate() {
        super.onCreate()
        firebaseManager.initFirebase(this)
    }
}


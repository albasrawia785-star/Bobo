package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.model.Operation
import com.example.data.model.OperationWithCustomer
import kotlinx.coroutines.flow.Flow

@Dao
interface OperationDao {
    @Transaction
    @Query("SELECT * FROM operations ORDER BY dateTime DESC")
    fun getAllOperationsWithCustomer(): Flow<List<OperationWithCustomer>>

    @Transaction
    @Query("SELECT * FROM operations WHERE customerId = :customerId ORDER BY dateTime DESC")
    fun getOperationsForCustomer(customerId: Long): Flow<List<Operation>>

    @Query("SELECT * FROM operations WHERE id = :id")
    suspend fun getOperationById(id: Long): Operation?

    @Query("SELECT * FROM operations WHERE isSynced = 0")
    suspend fun getUnsyncedOperations(): List<Operation>

    @Query("UPDATE operations SET isSynced = :isSynced WHERE id = :id")
    suspend fun updateSyncStatus(id: Long, isSynced: Boolean)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOperation(operation: Operation): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOperations(operations: List<Operation>)

    @Delete
    suspend fun deleteOperation(operation: Operation)

    @Query("DELETE FROM operations WHERE id = :id")
    suspend fun deleteOperationById(id: Long)

    @Query("SELECT SUM(amount) FROM operations WHERE type = 'DEBT'")
    fun getTotalDebtAddedSum(): Flow<Long?>

    @Query("SELECT SUM(amount) FROM operations WHERE type = 'PAYMENT'")
    fun getTotalPaymentsSum(): Flow<Long?>
}

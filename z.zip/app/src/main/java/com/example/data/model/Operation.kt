package com.example.data.model

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

enum class OperationType {
    DEBT,     // دين جديد
    PAYMENT   // تسديد
}

@Entity(
    tableName = "operations",
    indices = [
        Index(value = ["customerId"]),
        Index(value = ["dateTime"])
    ],
    foreignKeys = [
        ForeignKey(
            entity = Customer::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class Operation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val type: OperationType,
    val amount: Long,
    val note: String = "",
    val dateTime: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false
)

data class OperationWithCustomer(
    @Embedded val operation: Operation,
    @Relation(
        parentColumn = "customerId",
        entityColumn = "id"
    )
    val customer: Customer?
)

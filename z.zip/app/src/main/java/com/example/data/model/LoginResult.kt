package com.example.data.model

sealed class LoginResult {
    data class Success(val manager: Manager) : LoginResult()
    object Disabled : LoginResult()
    object InvalidCredentials : LoginResult()
    data class Error(val message: String) : LoginResult()
}

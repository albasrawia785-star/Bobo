package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// FinTech Modern Palette
val PrimaryBlue = Color(0xFF2563EB)        // #2563EB Main Primary Blue
val AccentCyan = Color(0xFF0EA5E9)         // #0EA5E9 Accent Cyan
val SuccessGreen = Color(0xFF22C55E)       // #22C55E Success Green
val WarningAmber = Color(0xFFF59E0B)       // #F59E0B Warning Amber
val DangerRed = Color(0xFFEF4444)          // #EF4444 Danger Red

val FinTechBackground = Color(0xFFF5F7FB)   // #F5F7FB Ultra Clean Background
val FinTechSurface = Color(0xFFFFFFFF)      // #FFFFFF Pure White Surface
val FinTechBorder = Color(0xFFE5E7EB)       // #E5E7EB Soft Border

val FinTechTextPrimary = Color(0xFF111827)   // #111827 Dark Primary Text
val FinTechTextSecondary = Color(0xFF6B7280) // #6B7280 Secondary Muted Text

// Container Tints
val PrimaryContainerTint = Color(0xFFEFF6FF)
val AccentContainerTint = Color(0xFFE0F2FE)
val SuccessContainerTint = Color(0xFFDCFCE7)
val WarningContainerTint = Color(0xFFFEF3C7)
val DangerContainerTint = Color(0xFFFEE2E2)

// Backwards Compatibility Aliases
val PrimaryIndigo = PrimaryBlue
val SecondaryPurple = AccentCyan
val EmeraldGreen = SuccessGreen
val AmberWarning = WarningAmber
val CrimsonRed = DangerRed
val SurfaceLight = FinTechBackground
val CardSurfaceLight = FinTechSurface
val BorderLight = FinTechBorder
val TextPrimaryDark = FinTechTextPrimary
val TextSecondaryDark = FinTechTextSecondary
val IndigoContainer = PrimaryContainerTint
val EmeraldContainer = SuccessContainerTint
val AmberContainer = WarningContainerTint
val CrimsonContainer = DangerContainerTint
val RoyalBlue = PrimaryBlue
val GradientStartBlue = PrimaryBlue
val GradientEndBlue = AccentCyan
val OrangeDebt = WarningAmber
val NavyPrimary = PrimaryBlue
val IndigoAccent = AccentCyan




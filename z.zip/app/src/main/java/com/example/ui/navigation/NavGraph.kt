package com.example.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.DebtApplication
import com.example.ui.screens.late.LateCustomersScreen
import com.example.ui.screens.late.LateCustomersViewModel
import com.example.ui.screens.login.LoginScreen
import com.example.ui.screens.main.MainScreen
import com.example.ui.screens.main.MainViewModel
import com.example.ui.screens.operations.OperationsScreen
import com.example.ui.screens.operations.OperationsViewModel
import com.example.ui.screens.reports.ReportsScreen
import com.example.ui.screens.reports.ReportsViewModel
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.settings.SettingsViewModel
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SurfaceLight
import kotlinx.coroutines.launch

@Composable
fun MainAppNavigation() {
    val navController = rememberNavController()
    val context = LocalContext.current.applicationContext as DebtApplication
    val coroutineScope = rememberCoroutineScope()

    val isLoggedInState by context.settingsRepository.isLoggedIn.collectAsStateWithLifecycle(initialValue = null)

    androidx.compose.runtime.LaunchedEffect(isLoggedInState) {
        if (isLoggedInState == true) {
            context.settingsRepository.restoreSessionToAldion()
        }
    }

    val mainViewModel: MainViewModel = viewModel(
        factory = MainViewModel.Factory(
            repository = context.repository,
            settingsRepository = context.settingsRepository
        )
    )

    val reportsViewModel: ReportsViewModel = viewModel(
        factory = ReportsViewModel.Factory(
            repository = context.repository,
            settingsRepository = context.settingsRepository
        )
    )

    val operationsViewModel: OperationsViewModel = viewModel(
        factory = OperationsViewModel.Factory(
            repository = context.repository
        )
    )

    val lateCustomersViewModel: LateCustomersViewModel = viewModel(
        factory = LateCustomersViewModel.Factory(
            repository = context.repository,
            settingsRepository = context.settingsRepository
        )
    )

    val settingsViewModel: SettingsViewModel = viewModel(
        factory = SettingsViewModel.Factory(
            settingsRepository = context.settingsRepository
        )
    )

    val items = listOf(
        Screen.Main,
        Screen.Reports,
        Screen.LateCustomers,
        Screen.Settings
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    if (isLoggedInState == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = RoyalBlue)
        }
        return
    }

    val initialDestination = if (isLoggedInState == true) Screen.Main.route else Screen.Login.route

    Scaffold(
        containerColor = SurfaceLight,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (currentRoute != Screen.Login.route) {
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                    shadowElevation = 8.dp
                ) {
                    NavigationBar(
                        containerColor = Color.White,
                        contentColor = RoyalBlue,
                        tonalElevation = 0.dp
                    ) {
                        items.forEach { screen ->
                            val isSelected = currentRoute == screen.route
                            NavigationBarItem(
                                icon = { Icon(imageVector = screen.icon, contentDescription = screen.title) },
                                label = {
                                    Text(
                                        text = screen.title,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                selected = isSelected,
                                onClick = {
                                    if (currentRoute != screen.route) {
                                        navController.navigate(screen.route) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = RoyalBlue,
                                    selectedTextColor = RoyalBlue,
                                    indicatorColor = Color(0xFFEFF6FF),
                                    unselectedIconColor = Color(0xFF94A3B8),
                                    unselectedTextColor = Color(0xFF94A3B8)
                                )
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = initialDestination,
            modifier = Modifier.padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            composable(Screen.Login.route) {
                LoginScreen(
                    onLoginSuccess = {
                        coroutineScope.launch {
                            context.settingsRepository.setLoggedIn(true)
                            navController.navigate(Screen.Main.route) {
                                popUpTo(Screen.Login.route) { inclusive = true }
                            }
                        }
                    }
                )
            }
            composable(Screen.Main.route) {
                MainScreen(viewModel = mainViewModel)
            }
            composable(Screen.Reports.route) {
                ReportsScreen(viewModel = reportsViewModel)
            }
            composable(Screen.LateCustomers.route) {
                LateCustomersScreen(viewModel = lateCustomersViewModel)
            }
            composable(Screen.Operations.route) {
                OperationsScreen(viewModel = operationsViewModel)
            }
            composable(Screen.Settings.route) {
                SettingsScreen(
                    viewModel = settingsViewModel,
                    onLogout = {
                        settingsViewModel.logout {
                            navController.navigate(Screen.Login.route) {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    }
                )
            }
        }
    }
}
